import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:shimmer/shimmer.dart';

class VISITA extends StatefulWidget {
  const VISITA({Key? key}) : super(key: key);

  @override
  State<VISITA> createState() => _VISITAState();
}

class _VISITAState extends State<VISITA> {
  late final String urlWithCredentials;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    // Encode the username and password for URL
    final username = Uri.encodeComponent('11164003');
    final password = Uri.encodeComponent('60-dayfreetrial');

    // Construct the URL with credentials
    urlWithCredentials =
        'http://$username:$password@mohabadaa-001-site1.gtempurl.com/thestudent.aspx';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Total Visitation'),
      ),
      body: Stack(
        children: [
          WebView(
            initialUrl: urlWithCredentials,
            javascriptMode: JavascriptMode.unrestricted,
            onPageFinished: (finish) {
              setState(() {
                _isLoading = false;
              });
            },
          ),
          _isLoading
              ? Shimmer.fromColors(
                  baseColor: Colors.grey[300]!,
                  highlightColor: Colors.grey[100]!,
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    color: Colors.white,
                  ),
                )
              : Container(),
        ],
      ),
    );
  }
}
