import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
class HIST extends StatefulWidget {
  const HIST({super.key});

  @override
  State<HIST> createState() => _HISTState();
}

class _HISTState extends State<HIST> {
    late final String urlWithCredentials;

  @override
  void initState() {
    super.initState();
    // Encode the username and password for URL
    final username = Uri.encodeComponent('11164003');
    final password = Uri.encodeComponent('60-dayfreetrial');

    // Construct the URL with credentials
    urlWithCredentials =
        'http://$username:$password@mohabadaa-001-site1.gtempurl.com/studentlgn.aspx';
  }
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: WebView(
        initialUrl: urlWithCredentials,
        javascriptMode: JavascriptMode.unrestricted,
      ),
    );
  }
}